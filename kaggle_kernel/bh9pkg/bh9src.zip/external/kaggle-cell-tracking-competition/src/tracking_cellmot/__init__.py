"""tracking-cellmot scorer."""
